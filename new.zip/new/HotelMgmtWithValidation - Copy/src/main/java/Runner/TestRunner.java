package Runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
features="C:\\Desktop\\BDD\\HotelMgmtWithValidation\\src\\test\\java\\Features\\HotelMgmt.feature" ,
glue= {"C:\\Desktop\\BDD\\HotelMgmtWithValidation\\src\\test\\java\\StepDefinition\\HotelMgmt.java"},
format= {"pretty","html:test-output"},
plugin="html:target-destination")

public class TestRunner {

}
